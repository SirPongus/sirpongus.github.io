3D model obtained from The Models Resource. The model has been ripped from Animal Crossing: Pocket Camp by Centrixe. Converted to Re-Volt by URV. Alterations (repaints, remodels, etc.) are encouraged.

The "masks" subfolder contains a few resources that can be helpful for basic repaints of this car. The "alt" subfolder contains a few alternative textures (as of update 18.0414, this is no longer relevant). More information can be found inside these folders.

Update 18.0414: Added custom engine sound and enabled alternative skins.