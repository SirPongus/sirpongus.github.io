////// DESCRIPTION //////

A high-poly Volkswagen Passat B6, carefully crafted to appear as a low-poly model. Not a whole lot of effort was put into this one.

////// ATTRIBUTES //////

CLASS:	Electric
RATING:	Advanced
SPEED:	34.6 MPH
ACCEL.:	6.4 seconds
WEIGHT:	1.7
TRANS.:	4WD

////// SOFTWARE USED //////

- Blender
- Paint.NET
- PRM2HUL
- CarLighting
- VIV Editor
- Zanoza Modeler v1.07b

////// CREDITS //////

Thanks to Birtz 3, who providing the original model.

Many thanks to Marv, Gotolei and Mladen for providing help.

////// NOTES //////

This car, originally created by Birtz 3 for NFS4, was converted to Re-Volt by URV on December 20, 2010. It was later updated on July 23, 2017, including model shading, a new set of Parameters, a new hull, a carbox, a shadow and a remodeled/remapped antenna.

You may use this car as a base for any future creations, as long as you give credit where is due (including credit to the original author).

As of the latest version, this car can be found on Re-Volt Zone (revoltzone.net) or Re-Volt I/O (creations.re-volt.io). If this car has been downloaded from anywhere else, it likely has not been uploaded by the original author and may include unintended differences.

The latest version of this car is from July 23, 2017.