This Clockwork is based on the same model I created for my All's Fair II entry, Herr Sch�nerbus. It is strongly influenced by RV_Passion's Clockworks, especially by Clockwork Savin, which it bears a strong resemblance to. This creation was done completely on a whim, more or less accidentally as I was messing about with the model in Blender.

Created by URV on July 26, 2017. Do as you will with this. Credit is appreciated.

Updated on April 14, 2018: Adjusted Inertia values with Jigebren's plugin and added Clockwork engine sound.