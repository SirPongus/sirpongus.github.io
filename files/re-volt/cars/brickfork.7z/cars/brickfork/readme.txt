It was the year 2017 of the Common Era. The invading armada of the fearsome Fidget Spinners took Earth by the storm, devastating everything in their path. However, the valiant and united forces of humanity fought back relentlessly, ultimately triumphant in their pursuit of victory.

Biometal, one of humanity's greatest heroes, scoffed at the invaders as they fled back to the hell from whence they came: "What'z next? A brick with a fork wedged into it?"

And so it was.