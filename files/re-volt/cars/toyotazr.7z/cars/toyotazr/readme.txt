////// DESCRIPTION //////

This is a remodel, remap and repaint of the Toyota MR2. It was created as a birthday gift for zipperrulez, whose real car happens to be a Toyota MR2, and his favourite Re-Volt car is, unsurprisingly, Zipper.

////// ATTRIBUTES //////

CLASS:	Glow
RATING:	Semi-Pro
SPEED:	38 MPH
ACCEL.:	6.2 seconds
WEIGHT:	1.4
TRANS.:	4WD

////// SOFTWARE USED //////

- 3ds max 12
- Blender
- Paint.NET
- PRM2HUL
- RVMinis5
- VIV Editor
- Zanoza Modeler v1.07b

////// CREDITS //////

Thanks to AJ_Lethal, who created the original model.

Many thanks to Skarma and Mladen for providing help with this creation.

Cheers, ZR. I initially dedicated this to you as a birthday gift, given what an awesome person I thought you were, and that hasn't changed a single bit.

////// NOTES //////

This car was originally created by URV on December 6, 2012. It was later updated on July 18, 2017, including model improvements (done by Mladen007), a new set of Parameters and a carbox.

If you wish to enable the headlights, you must open up Parameters.txt and change the ModelNum to 3 in Car Spinner Details.

You may use this car as a base for any future creations, as long as you give credit where is due (including credit to the original author).

As of the latest version, this car can be found on Re-Volt Zone (revoltzone.net) or Re-Volt I/O (creations.re-volt.io). If this car has been downloaded from anywhere else, it likely has not been uploaded by the original author and may include unintended differences.

The latest version of this car is from July 18, 2017.