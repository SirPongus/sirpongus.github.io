﻿+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+                                                                YAMAHA YZR500 +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Main Infos          :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ Name          : Yamaha YZR500                                                +
+ Creator       : urbanrocker                                                  +
+ Type          : Conversion                                                   +
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Technicals          :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ Class         : Glow                                                         +
+ Rating        : Pro                                                          +
+ Top speed     : 48 mph (76km/h)                                              +
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Models              :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ Body tris*    : 1690                                                         +
+ Wheel tris*   : 479, 29,  497, 29                                            +
+    ~tris: triangles                                                          +
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Contact             :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ E-mail        : urbanrocker@yahoo.com                                        +
+ Site          : -                                                            +
+ Other		: http://z3.invisionfree.com/Revolt_Live                       +
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Comments            :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ Thanks to:                                                                   + 
+ 
                                                                             + 
+ 
- Citywalker, for helping with the parameters;                               + 
+ 
- Halogaland, for separating the wheels from the body;                       + 
+ 
- Zipperrulez, miromiro, KDL, Tavi_96, Adamodell, TomoAlien,                 + 
+ swordlessroy/leetcake, Burner94, THE_HARVESTER, R6TurboExtreme, Nero and     + 
+ many others for many reasons;                                                + 
+ 
- You, for downloading this car.                                             + 
+ 
                                                                             + 
+ 
...And, of course, me. Because I finally moved my lazy ass and made a        + 
+ conversion.                                                                  + 
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
+   ______________________                                                     +
+  [ Copyrights          :]                                                    +
+   ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨                                                     +
+ (c) urbanrocker 2011                                                         + 
+ (c) Thomas Egelkraut 2000                                                    +
+                                                                              +
+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+

._____________________________________________________.
|                           Car Manager :: Reload     |
¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨
7 May 2011, 00:10