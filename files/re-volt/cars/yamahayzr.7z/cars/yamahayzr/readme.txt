////// DESCRIPTION //////

This vehicle has been converted to Re-Volt with the aim of introducing motorcycles to the game. While unrealistically nimble and extremely clumsy with weapons, it has, indeed, achieved its goal.

////// ATTRIBUTES //////

CLASS:	Glow
RATING:	Pro
SPEED:	58.6 MPH
ACCEL.:	20.6 seconds
WEIGHT:	2.0
TRANS.:	RWD

////// TOOLS USED //////

- Blender
- Paint.NET

////// CREDITS //////

Thanks to Thomas Egelkraut for providing the original model.

Thanks to halogaland (separating the wheels) and Citywalker (creating the Parameters) for contributing to the creation of this vehicle.

////// NOTES //////

This custom vehicle, converted from NFS4, has been released on May 6, 2011. It was later updated on July 18, 2017, including a carbox, a shadow, a moving head and small improvements to the Parameters.

You may use this car as a base for any future creations, as long as you give credit where is due (including credit to the authors of the original resources).

As of the latest version, this car can be found on Re-Volt Zone (revoltzone.net) or Re-Volt I/O (creations.re-volt.io). If this car has been downloaded from anywhere else, it likely has not been uploaded by the original author and may include unintended differences.

The latest version of this car is from April 29, 2017, which enables the alternative skin and adds a custom engine sound.