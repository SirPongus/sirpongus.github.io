Hi. UrbanRocker asked me to parameter this bike, i.e. to make it lean like a bike should. This I did, taking notes from Bimota Tesi by Volty. Also, the AI should be well capable of riding it now. Happy hunting when trying to catch the little speeder! :) (Bonnet view recommended, courtesy of WolfR4 from Jigebren.)

-----
Citywalker

(I can be contacted at Our Revolt Pub or Re-Volt Live.)

