==============================================================================================================================================
Introduction
==============================================================================================================================================

Once upon of time, there was an egg.
The egg was violated multiple times by HowToBasic.
Upon passing of time, the egg became deformed.
Due to a lifetime of torture, it became filled with rage and hatred.
Thus, it decided to express it by dedicating its life to metal, soon after escaping.
Years upon years of music, it felt like its life was missing something.
And then it hit him. Racing.
It considered many, many challenges, yet most of them were not appropriate.
Dangerous, large cars, going at high speeds -- it could not compete with them.
Yet, one day, a mysterious figure approached it, and he said:
"Thou must join tiny cars."
And then, the egg realized that it could compete in R/C car racing.
It spent days, months, years of practicing his running.
Until one day, it finally felt ready.
It ran to the track.
An egg between vehicles.
It felt intimidated, yet it could not let bring itself down.
"Three," it heard as it positioned itself at the starting line.
"Two," it looked around, as the R/C cars were growling around him.
"One," it felt the yolk boiling inside it.
"Go!"

==============================================================================================================================================
Author notes
==============================================================================================================================================

That thing above is possibly the most retarded thing I ever wrote. Fits in with the car, now that I think of it.

Alright, so. To put it shortly, I was fucking around in 3ds max, and somehow ended up with this model.
I gave it a texture, converted it into Re-Volt, gave it fitting parameters (to the best of my knowledge) and BAM! you've got a running metal-egg.
And you know what? I'm fucking proud of it. Fits in well with my Banana Shplit.

Now now, don't worry. I'll actually do something serious for once. One day. Probably never. Ahem.
And yes, I couldn't bother to make a serious set of parameters. Give me a break. I'm lazy as hell.
This should suffice anyway, since basically no one 

==============================================================================================================================================
Car notes
==============================================================================================================================================

Name: Deformed Metalegg
Type: Original
Class: Electric
Rating: Rookie
Speed: 27
Acc: 3.4
Weight: 1.1
Transmission: 4WD (strange, doesn't it have only 2 legs?)

==============================================================================================================================================
How this complete piece of shit was created
==============================================================================================================================================

Tools used: 3ds max, Paint.NET, ZModeler, RV-Minis, Chaos Tools, Notepad, Google (yesit'satool,shutup).
Work time: Roughly 5-10 hours. I'm a slowpoke.
Was it worth it?: It's a metalhead egg running like an idiot on a track, being overtaken by R/C cars. Why don't you answer that yourself?

==============================================================================================================================================
Credits
==============================================================================================================================================

Marv: Inspired me to open up 3ds max by teaching me stuff in Blender. No, don't ask me which one I prefer -- I like them both.
Skarma & LWG: For providing feedback. The former is also known as a faggot. I think he lives in a big bag of potatoes.

==============================================================================================================================================
Copyright
==============================================================================================================================================

Do whatever you want with this, haha. It's not like I give many fucks about an egg-car which I barely put any effort in.