////// DESCRIPTION //////

This is a high-poly (nearly 10,000 faces) conversion from NFS4, designed to handle like a heavy, electric R/C car with a metal body.

////// ATTRIBUTES //////

CLASS:	Electric
RATING:	Advanced
SPEED:	35.7 MPH
ACCEL.:	8.3 seconds
WEIGHT:	2.6
TRANS.:	RWD

////// SOFTWARE USED //////

- 3ds max 12
- Blender
- Paint.NET
- PRM2HUL
- RVMinis5
- VIV Editor
- Zanoza Modeler v1.07b

////// CREDITS //////

Thanks to AJ_Lethal, who created the original model.

Many thanks to Skarma and Mladen for providing help with this creation.

////// NOTES //////

This car, originally created by AJ_Lethal for NFS4, was converted to Re-Volt by URV on December 6, 2012. It was later updated on July 18, 2017, including model improvements (done by Mladen007), extra textures (done by Mladen007), a new set of Parameters, a carbox and a remodeled/remapped antenna.

If you wish to disable the headlights, you must open up Parameters.txt and change the ModelNum to -1 in Car Spinner Details.

You may use this car as a base for any future creations, as long as you give credit where is due (including credit to the original author).

As of the latest version, this car can be found on Re-Volt Zone (revoltzone.net) or Re-Volt I/O (creations.re-volt.io). If this car has been downloaded from anywhere else, it likely has not been uploaded by the original author and may include unintended differences.

The latest version of this car is from July 18, 2017.